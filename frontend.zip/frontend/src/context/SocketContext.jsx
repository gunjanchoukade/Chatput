import React, { useRef } from 'react'
import { createContext ,useEffect} from 'react'
import { io } from 'socket.io-client';
import useUserStore from '../../store/userStore';


export const socketaDataContext = createContext()

// Use refs to always access the latest selectedUser and chatType inside your socket event handler.
// This will ensure addMessage works as expected, even when those values change.

// Your code for handling the "receiveMessage" event is correct in terms of logic, but it has a common React pitfall:
// selectedUser and chatType may be stale inside the socket event handler because they are captured when the effect runs, and will not update if those values change later.

// This means that even though you see the message in your console, the addMessage function may not run as expected if selectedUser or chatType have changed since the effect was created.

const SocketContext = ({children}) => {
    const {authUser} = useUserStore()
    const backendURL = import.meta.env.VITE_backendURL;
    const socket = useRef(null)
    const {selectedUser,chatType,addMessage} = useUserStore()

    // Refs to always have latest values
    const selectedUserRef = useRef(selectedUser)
    const chatTypeRef = useRef(chatType)

    useEffect(() => {
        selectedUserRef.current = selectedUser
        chatTypeRef.current = chatType
    }, [selectedUser, chatType])

    useEffect(()=>{
        if(authUser){
            socket.current = io(backendURL,{
                withCredentials:true,
                query:{
                    userId:authUser._id,
                }
            }) 
            socket.current.on("connect",()=>{
                console.log('connected to socket server')
            })
            //without this the message for a particular user will also be displayed for other user
            socket.current.on("receiveMessage",(message)=>{
                const isSender = message.sender._id === authUser._id && message.receiver._id === selectedUserRef.current._id;
                const isReceiver = message.sender._id === selectedUserRef.current._id && message.receiver._id === authUser._id;
                if(isSender || isReceiver){
                    console.log(message)
                    addMessage(message)
                }
            })

            return ()=>{
                socket.current.disconnect();
            }
        }
    },[authUser, backendURL, addMessage])
  return (
    <socketaDataContext.Provider value={socket.current}>
        {children}
    </socketaDataContext.Provider>
  )
}

export default SocketContext
