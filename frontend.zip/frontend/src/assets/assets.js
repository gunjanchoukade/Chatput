import authPageImage from './authpageimage.png';

export { authPageImage };