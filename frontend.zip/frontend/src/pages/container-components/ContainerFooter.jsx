import React, { useContext, useState } from 'react'
import { SendHorizonal ,LinkIcon,Sticker} from 'lucide-react'
import EmojiPicker from 'emoji-picker-react'
import SocketContext, { socketaDataContext } from '../../context/socketContext';
import useUserStore from '../../../store/userStore';
const ContainerFooter = () => {
    const [showEmoji, setShowEmoji] = useState(false);
    const [isMounted, setIsMounted] = useState(false);
    const [message,setMessage] = useState("")
    const {selectedUser,authUser,chatType} = useUserStore();
   
    const toggleEmoji = () => {
      if (!showEmoji) {
          setIsMounted(true);            // mount first
          setTimeout(() => setShowEmoji(true),0); // small delay to trigger transition
      } else {
          setShowEmoji(false);           // hide instantly
          setIsMounted(false);           // unmount instantly after hide
      }
    };

    const addEmojiToMessage=(emojiData)=>{
      setMessage((prev)=>prev+emojiData.emoji);
    }

    const socket = useContext(socketaDataContext)
    const handleSendMessage=async()=>{
      if(chatType === 'contact'){
        socket.emit("sendMessage",{
          sender:authUser._id,
          receiver:selectedUser._id,
          content:message,
          fileUrl:undefined,
          messageType:'text'
        })
      }
    }

  return (
    <div className='absolute bottom-0 h-[10vh] flex items-center w-full px-4'>
      <div className={`absolute top-[-400px] h-[30vh] transition-all duration-300 ${
            showEmoji ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
        }`}>
        <EmojiPicker  onEmojiClick={(emojiData)=>addEmojiToMessage(emojiData)}
        open={showEmoji} theme='dark' height={400} width={350} searchDisabled={true}  />
      </div>
      <div className='w-full flex '>
        <div className='flex'>
            <input onChange={(e)=>setMessage(e.target.value)} value={message}
            className='md:w-[63vw] w-[78vw] bg-[#303036] text-white border-none outline-none p-4 rounded-md pr-23'
            type="text" placeholder='Type your message....' />
            <span 
            onClick={toggleEmoji}
            className='text-white absolute right-30 bottom-8 lg:right-40 lg:bottom-6'><Sticker/>
            </span>
            <span className="text-yellow-300 absolute right-20 bottom-8 lg:right-30 lg:bottom-6"><LinkIcon/></span>
        </div>
        <button onClick={handleSendMessage} 
        className='bg-[#505269] text-white px-4 py-2 rounded-md ml-2'> <SendHorizonal /></button>
       
      </div>
    </div>
  )
}

export default ContainerFooter
