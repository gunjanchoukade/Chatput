import React, { useContext, useEffect, useRef } from 'react';
import useUserStore from '../../../store/userStore';
import { socketaDataContext } from '../../context/socketContext';
import axios from 'axios';
import { useState } from 'react';

const ContainerBody = () => {
  const { authUser, selectedUser,chatMessages ,chatType,setChatMessages} = useUserStore();
  const scrollRef = useRef();
  const lastFetchedRef = useRef(null);
  



  const getUsers = async()=>{
    try {
      console.log("get user is called")
      const response = await axios.post(`${import.meta.env.VITE_backendURL}/messages/getUsers`,{user2:selectedUser._id},{withCredentials:true})
      if(response.status==200){
        setChatMessages(response.data.messages)
      }
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    // Scroll to bottom when chatMessages change
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  useEffect(() => {
    if (
      selectedUser?._id &&
      chatType === "contact" &&
      lastFetchedRef.current !== selectedUser._id
    ) {
      console.log("🔄 Fetching new chat for:", selectedUser._id);
      getUsers();
      lastFetchedRef.current = selectedUser._id;
    } else {
      console.log("⛔ Skipping fetch. Already fetched for this user.");
    }
  }, [authUser]);

  function formatDateTime(timestamp) {
    const date = new Date(timestamp);
    const options = {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    };
    return date.toLocaleString('en-IN', options);
  }

  return (
    <div className="px-4 overflow-y-auto h-[80vh] py-2 bg-[#1a1a1a]">
      <div className="flex flex-col gap-2">
        {chatMessages.map((message, index) =>
          ( message.sender._id === selectedUser?._id|| message.receiver._id === selectedUser?._id) ? (
            <div
              key={index}
              className={`flex ${message.sender._id === authUser._id ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`p-3 rounded-xl max-w-[70%] text-white text-sm ${
                  message.sender._id === authUser._id
                    ? 'bg-blue-600 rounded-br-none'
                    : 'bg-gray-700 rounded-bl-none'
                }`}
              >
                <p>{message.content}</p>
                <p className="text-[10px] text-gray-300 text-right mt-1">
                  {formatDateTime(message.timeStamps)}
                </p>
              </div>
            </div>
          ) : null
        )}
        <div ref={scrollRef} />
      </div>
    </div>
  );
};

export default ContainerBody;
