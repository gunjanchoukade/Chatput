
import { create} from "zustand";

const useUserStore = create((set,get)=>({
    authUser:null,
    setAuthUser : (user)=>set({authUser:user}),
    //chat
    chatMessages:[],
    chatType:null,  //single person or group chat
    selectedUser:null, //user selected for chatting
    setSelectedUser : (user)=>set({selectedUser:user}),
    setChatType:(type)=>set({chatType:type}),
    setChatMessages:(messages)=>set({chatMessages:messages}),
    addMessage: (message) => {
        const chatMessages = get().chatMessages;
        set({
            chatMessages: [...chatMessages, message]
        });
    },
    closeChat:()=>set({chatType:null,selectedUser:null,chatMessages:[]}),
}))
export default useUserStore;